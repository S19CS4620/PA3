/**
 * PA2error
 * 
 * 
 * MMS, 2/17/11
 */
import meggy.Meggy;

class PA2bluedot {
       public static void main(String[] whatever){
               Meggy.setPixel( (byte)84me, (byte)2, Meggy.Color.BLUE );
        }
}
